﻿using System;
using AddressBookApp;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AddressBook.Test
{
    [TestClass]
    public class TestContactPersonValidation
    {
        [TestMethod]
        public void FirstNameShouldNotAcceptNullOrWhitespaceString()
        {
            ContactPerson personUnderTest = new ContactPerson();
            string errorMessage = string.Empty;

            personUnderTest.FirstName = "";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "       ";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);
        }

        [TestMethod]
        public void FirstNameShouldAcceptAlphabetOnly()
        {
            ContactPerson personUnderTest = new ContactPerson();
            string errorMessage = string.Empty;

            personUnderTest.FirstName = "KimSher12312432";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "!@#!@#$@$%&((_)(";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "22342342342";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "asjaslda!@#!#$$#^#$^";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);

        }

        [TestMethod]
        public void FirstNameShouldNotAcceptGreaterThan30Characters()
        {
            ContactPerson personUnderTest = new ContactPerson();
            string errorMessage = string.Empty;

            //31 characters
            personUnderTest.FirstName = "qwertyuiopasdfghjklzxcvbnmqwerq";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsNotNull(errorMessage);

            //30 characters
            personUnderTest.FirstName = "KimberlyRoseDiazDelaCruzMikabe";
            personUnderTest.Validate();
            errorMessage = personUnderTest.GetErrorMessage("FirstName");
            Assert.IsTrue(string.IsNullOrEmpty(errorMessage));
        }

        [TestMethod]
        public void LastNameShouldAcceptNullOrWhitespaceString()
        {
            ContactPerson personUnderTest = new ContactPerson();
            string errorMessage = string.Empty;

            personUnderTest.LastName = "";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.LastName = "       ";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);
        }

        [TestMethod]
        public void LastNameShouldAcceptAlphabetOnly()
        {
            ContactPerson personUnderTest = new ContactPerson();
            string errorMessage = string.Empty;

            personUnderTest.LastName = "LastName234234";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "!@#!@#$@$%&((_)(";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "22342342342";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);

            personUnderTest.FirstName = "asjaslda!@#!#$$#^#$^";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);

        }

        [TestMethod]
        public void LastNameShouldNotAcceptGreaterThan30Characters()
        {
            ContactPerson personUnderTest = new ContactPerson();
            string errorMessage = string.Empty;

            //31 characters
            personUnderTest.LastName = "qwertyuiopasdfghjklzxcvbnmqwerq";
            Assert.IsFalse(personUnderTest.IsValid);
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsNotNull(errorMessage);

            //30 characters
            personUnderTest.LastName = "KimberlyRoseDiazDelaCruzMikabe";
            personUnderTest.Validate();
            errorMessage = personUnderTest.GetErrorMessage("LastName");
            Assert.IsTrue(string.IsNullOrEmpty(errorMessage));
        }

    }
}
