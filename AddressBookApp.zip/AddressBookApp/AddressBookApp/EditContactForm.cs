﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddressBookApp
{
    public partial class EditContactForm : Form
    {
        private ContactList contactList;
        private string selectedGender;
        private int selectedId;

        public EditContactForm(ContactPerson person)
        {
            contactList = new ContactList();
            selectedId = person.Id;
            InitializeComponent();
            firstNameTxtbox.Text = person.FirstName;
            lastNameTxtbox.Text = person.LastName;
            phoneNumTxtbox.Text = person.PhoneNumber;
            addressTxtbox.Text = person.Address;
            selectedGender = person.Gender;
            if (selectedGender == "F")
            {
                femaleGenRadioBtn.Checked = true;
            }
            else
            {
                maleGenRadioBtn.Checked = true;
            }
            ValidateFields();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm goToDashboardForm = new DashboardForm();
            goToDashboardForm.ShowDialog();
            this.Close();
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            ContactPerson editContactPerson = new ContactPerson()
            {
                Id = selectedId,
                FirstName = firstNameTxtbox.Text,
                LastName = lastNameTxtbox.Text,
                PhoneNumber = phoneNumTxtbox.Text,
                Address = addressTxtbox.Text,
                Gender = selectedGender
            };

            var result = contactList.Edit(editContactPerson);
            
            SuccessfulEditMessage showSuccessfulEditMessage = new SuccessfulEditMessage();
            showSuccessfulEditMessage.TopMost = true;
            showSuccessfulEditMessage.ShowDialog();
            this.Close();
        }

        private void firstNameTxtbox_TextChanged(object sender, EventArgs e)
        {
            ValidateFields();
        }

        private void lastNameTxtbox_TextChanged(object sender, EventArgs e)
        {
            ValidateFields();
        }


        private void phoneNumTxtbox_TextChanged(object sender, EventArgs e)
        {
            ValidateFields();
        }

        private void addressTxtbox_TextChanged(object sender, EventArgs e)
        {
            ValidateFields();
        }

        private void ValidateFields()
        {
            var contactPerson = new ContactPerson()
            {
                Id = selectedId,
                FirstName = firstNameTxtbox.Text,
                LastName = lastNameTxtbox.Text,
                PhoneNumber = phoneNumTxtbox.Text,
                Address = addressTxtbox.Text,
                Gender = selectedGender
            };

            if (!contactPerson.IsValid)
            {
                firstNameErrorLbl.Text = contactPerson.GetErrorMessage("FirstName");
                lastNameErrorLbl.Text = contactPerson.GetErrorMessage("LastName");
                phoneNumErrorLbl.Text = contactPerson.GetErrorMessage("PhoneNumber");
                addressErrorLbl.Text = contactPerson.GetErrorMessage("Address");
            }
            else
            {
                clearErrorMessages();
            }
        }

        private void clearErrorMessages()
        {
            firstNameErrorLbl.Text = string.Empty;
            lastNameErrorLbl.Text = string.Empty;
            phoneNumErrorLbl.Text = string.Empty;
            addressErrorLbl.Text = string.Empty;
        }
    }
}
