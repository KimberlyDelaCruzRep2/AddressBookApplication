﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddressBookApp
{
    public partial class DeleteMessage : Form
    {
        private ContactList contactList;
        private int selectedId;
        public DeleteMessage(ContactPerson person)
        {
            contactList = new ContactList();
            InitializeComponent();
            selectedId = person.Id;
        }

        private void confirmDeleteBtn_Click(object sender, EventArgs e)
        {
            Hide();
            ContactPerson deleleContactPerson = new ContactPerson()
            {
                Id = selectedId
            };

            var result = contactList.Delete(deleleContactPerson);

            SuccessfulDeleteMessage showSuccessfulDeleteMessage = new SuccessfulDeleteMessage();
            showSuccessfulDeleteMessage.TopMost = true;
            showSuccessfulDeleteMessage.ShowDialog();
            this.Close();
        }

        private void cancelDeleteBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm goToDashboardForm = new DashboardForm();
            goToDashboardForm.ShowDialog();
            this.Close();
        }
    }
}
