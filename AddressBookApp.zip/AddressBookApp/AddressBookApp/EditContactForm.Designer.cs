﻿namespace AddressBookApp
{
    partial class EditContactForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditContactForm));
            this.cancelBtn = new System.Windows.Forms.Button();
            this.saveBtn = new System.Windows.Forms.Button();
            this.maleGenRadioBtn = new System.Windows.Forms.RadioButton();
            this.femaleGenRadioBtn = new System.Windows.Forms.RadioButton();
            this.addressTxtbox = new System.Windows.Forms.TextBox();
            this.phoneNumTxtbox = new System.Windows.Forms.TextBox();
            this.lastNameTxtbox = new System.Windows.Forms.TextBox();
            this.firstNameTxtbox = new System.Windows.Forms.TextBox();
            this.genderLbl = new System.Windows.Forms.Label();
            this.addressLbl = new System.Windows.Forms.Label();
            this.phoneNumlbl = new System.Windows.Forms.Label();
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.firstNameLbl = new System.Windows.Forms.Label();
            this.addAddressPageLbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.firstNameErrorLbl = new System.Windows.Forms.Label();
            this.lastNameErrorLbl = new System.Windows.Forms.Label();
            this.phoneNumErrorLbl = new System.Windows.Forms.Label();
            this.addressErrorLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cancelBtn
            // 
            this.cancelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(349, 424);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 29);
            this.cancelBtn.TabIndex = 43;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.SystemColors.Control;
            this.saveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.Location = new System.Drawing.Point(246, 424);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 29);
            this.saveBtn.TabIndex = 42;
            this.saveBtn.Text = "Update";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // maleGenRadioBtn
            // 
            this.maleGenRadioBtn.AutoSize = true;
            this.maleGenRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.maleGenRadioBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maleGenRadioBtn.Location = new System.Drawing.Point(349, 365);
            this.maleGenRadioBtn.Name = "maleGenRadioBtn";
            this.maleGenRadioBtn.Size = new System.Drawing.Size(66, 24);
            this.maleGenRadioBtn.TabIndex = 41;
            this.maleGenRadioBtn.TabStop = true;
            this.maleGenRadioBtn.Text = "Male";
            this.maleGenRadioBtn.UseVisualStyleBackColor = false;
            // 
            // femaleGenRadioBtn
            // 
            this.femaleGenRadioBtn.AutoSize = true;
            this.femaleGenRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.femaleGenRadioBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.femaleGenRadioBtn.Location = new System.Drawing.Point(246, 365);
            this.femaleGenRadioBtn.Name = "femaleGenRadioBtn";
            this.femaleGenRadioBtn.Size = new System.Drawing.Size(85, 24);
            this.femaleGenRadioBtn.TabIndex = 40;
            this.femaleGenRadioBtn.TabStop = true;
            this.femaleGenRadioBtn.Text = "Female";
            this.femaleGenRadioBtn.UseVisualStyleBackColor = false;
            // 
            // addressTxtbox
            // 
            this.addressTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressTxtbox.Location = new System.Drawing.Point(246, 306);
            this.addressTxtbox.Name = "addressTxtbox";
            this.addressTxtbox.Size = new System.Drawing.Size(331, 27);
            this.addressTxtbox.TabIndex = 39;
            this.addressTxtbox.TextChanged += new System.EventHandler(this.addressTxtbox_TextChanged);
            // 
            // phoneNumTxtbox
            // 
            this.phoneNumTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumTxtbox.Location = new System.Drawing.Point(246, 241);
            this.phoneNumTxtbox.Name = "phoneNumTxtbox";
            this.phoneNumTxtbox.Size = new System.Drawing.Size(331, 27);
            this.phoneNumTxtbox.TabIndex = 38;
            this.phoneNumTxtbox.TextChanged += new System.EventHandler(this.phoneNumTxtbox_TextChanged);
            // 
            // lastNameTxtbox
            // 
            this.lastNameTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameTxtbox.Location = new System.Drawing.Point(246, 170);
            this.lastNameTxtbox.Name = "lastNameTxtbox";
            this.lastNameTxtbox.Size = new System.Drawing.Size(331, 27);
            this.lastNameTxtbox.TabIndex = 37;
            this.lastNameTxtbox.TextChanged += new System.EventHandler(this.lastNameTxtbox_TextChanged);
            // 
            // firstNameTxtbox
            // 
            this.firstNameTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameTxtbox.Location = new System.Drawing.Point(246, 115);
            this.firstNameTxtbox.Name = "firstNameTxtbox";
            this.firstNameTxtbox.Size = new System.Drawing.Size(331, 27);
            this.firstNameTxtbox.TabIndex = 36;
            this.firstNameTxtbox.TextChanged += new System.EventHandler(this.firstNameTxtbox_TextChanged);
            // 
            // genderLbl
            // 
            this.genderLbl.AutoSize = true;
            this.genderLbl.BackColor = System.Drawing.Color.Transparent;
            this.genderLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderLbl.Location = new System.Drawing.Point(110, 365);
            this.genderLbl.Name = "genderLbl";
            this.genderLbl.Size = new System.Drawing.Size(64, 20);
            this.genderLbl.TabIndex = 35;
            this.genderLbl.Text = "Gender";
            // 
            // addressLbl
            // 
            this.addressLbl.AutoSize = true;
            this.addressLbl.BackColor = System.Drawing.Color.Transparent;
            this.addressLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLbl.Location = new System.Drawing.Point(110, 306);
            this.addressLbl.Name = "addressLbl";
            this.addressLbl.Size = new System.Drawing.Size(71, 20);
            this.addressLbl.TabIndex = 34;
            this.addressLbl.Text = "Address";
            // 
            // phoneNumlbl
            // 
            this.phoneNumlbl.AutoSize = true;
            this.phoneNumlbl.BackColor = System.Drawing.Color.Transparent;
            this.phoneNumlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumlbl.Location = new System.Drawing.Point(110, 244);
            this.phoneNumlbl.Name = "phoneNumlbl";
            this.phoneNumlbl.Size = new System.Drawing.Size(120, 20);
            this.phoneNumlbl.TabIndex = 33;
            this.phoneNumlbl.Text = "Phone Number";
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.AutoSize = true;
            this.lastNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.lastNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLbl.Location = new System.Drawing.Point(109, 177);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(91, 20);
            this.lastNameLbl.TabIndex = 32;
            this.lastNameLbl.Text = "Last Name";
            // 
            // firstNameLbl
            // 
            this.firstNameLbl.AutoSize = true;
            this.firstNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.firstNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameLbl.Location = new System.Drawing.Point(109, 118);
            this.firstNameLbl.Name = "firstNameLbl";
            this.firstNameLbl.Size = new System.Drawing.Size(92, 20);
            this.firstNameLbl.TabIndex = 31;
            this.firstNameLbl.Text = "First Name";
            // 
            // addAddressPageLbl
            // 
            this.addAddressPageLbl.AutoSize = true;
            this.addAddressPageLbl.BackColor = System.Drawing.Color.Transparent;
            this.addAddressPageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addAddressPageLbl.Location = new System.Drawing.Point(106, 33);
            this.addAddressPageLbl.Name = "addAddressPageLbl";
            this.addAddressPageLbl.Size = new System.Drawing.Size(267, 32);
            this.addAddressPageLbl.TabIndex = 30;
            this.addAddressPageLbl.Text = "Edit Address Page";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(85, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // firstNameErrorLbl
            // 
            this.firstNameErrorLbl.AutoSize = true;
            this.firstNameErrorLbl.BackColor = System.Drawing.Color.Transparent;
            this.firstNameErrorLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameErrorLbl.Location = new System.Drawing.Point(251, 145);
            this.firstNameErrorLbl.Name = "firstNameErrorLbl";
            this.firstNameErrorLbl.Size = new System.Drawing.Size(0, 20);
            this.firstNameErrorLbl.TabIndex = 44;
            // 
            // lastNameErrorLbl
            // 
            this.lastNameErrorLbl.AutoSize = true;
            this.lastNameErrorLbl.BackColor = System.Drawing.Color.Transparent;
            this.lastNameErrorLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameErrorLbl.Location = new System.Drawing.Point(251, 200);
            this.lastNameErrorLbl.Name = "lastNameErrorLbl";
            this.lastNameErrorLbl.Size = new System.Drawing.Size(0, 20);
            this.lastNameErrorLbl.TabIndex = 45;
            // 
            // phoneNumErrorLbl
            // 
            this.phoneNumErrorLbl.AutoSize = true;
            this.phoneNumErrorLbl.BackColor = System.Drawing.Color.Transparent;
            this.phoneNumErrorLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumErrorLbl.Location = new System.Drawing.Point(251, 271);
            this.phoneNumErrorLbl.Name = "phoneNumErrorLbl";
            this.phoneNumErrorLbl.Size = new System.Drawing.Size(0, 20);
            this.phoneNumErrorLbl.TabIndex = 46;
            // 
            // addressErrorLbl
            // 
            this.addressErrorLbl.AutoSize = true;
            this.addressErrorLbl.BackColor = System.Drawing.Color.Transparent;
            this.addressErrorLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressErrorLbl.Location = new System.Drawing.Point(250, 336);
            this.addressErrorLbl.Name = "addressErrorLbl";
            this.addressErrorLbl.Size = new System.Drawing.Size(0, 20);
            this.addressErrorLbl.TabIndex = 47;
            // 
            // EditContactForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(735, 529);
            this.Controls.Add(this.addressErrorLbl);
            this.Controls.Add(this.phoneNumErrorLbl);
            this.Controls.Add(this.lastNameErrorLbl);
            this.Controls.Add(this.firstNameErrorLbl);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.maleGenRadioBtn);
            this.Controls.Add(this.femaleGenRadioBtn);
            this.Controls.Add(this.addressTxtbox);
            this.Controls.Add(this.phoneNumTxtbox);
            this.Controls.Add(this.lastNameTxtbox);
            this.Controls.Add(this.firstNameTxtbox);
            this.Controls.Add(this.genderLbl);
            this.Controls.Add(this.addressLbl);
            this.Controls.Add(this.phoneNumlbl);
            this.Controls.Add(this.lastNameLbl);
            this.Controls.Add(this.firstNameLbl);
            this.Controls.Add(this.addAddressPageLbl);
            this.Controls.Add(this.pictureBox1);
            this.Name = "EditContactForm";
            this.Text = "EditContactForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.RadioButton maleGenRadioBtn;
        private System.Windows.Forms.RadioButton femaleGenRadioBtn;
        private System.Windows.Forms.TextBox addressTxtbox;
        private System.Windows.Forms.TextBox phoneNumTxtbox;
        private System.Windows.Forms.TextBox lastNameTxtbox;
        private System.Windows.Forms.TextBox firstNameTxtbox;
        private System.Windows.Forms.Label genderLbl;
        private System.Windows.Forms.Label addressLbl;
        private System.Windows.Forms.Label phoneNumlbl;
        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.Label firstNameLbl;
        private System.Windows.Forms.Label addAddressPageLbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label firstNameErrorLbl;
        private System.Windows.Forms.Label lastNameErrorLbl;
        private System.Windows.Forms.Label phoneNumErrorLbl;
        private System.Windows.Forms.Label addressErrorLbl;
    }
}