﻿namespace AddressBookApp
{
    partial class DeleteMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeleteMessage));
            this.errorIcon = new System.Windows.Forms.PictureBox();
            this.deleteMessageLbl = new System.Windows.Forms.Label();
            this.confirmDeleteBtn = new System.Windows.Forms.Button();
            this.cancelDeleteBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // errorIcon
            // 
            this.errorIcon.BackColor = System.Drawing.Color.Transparent;
            this.errorIcon.Image = ((System.Drawing.Image)(resources.GetObject("errorIcon.Image")));
            this.errorIcon.Location = new System.Drawing.Point(78, 21);
            this.errorIcon.Name = "errorIcon";
            this.errorIcon.Size = new System.Drawing.Size(46, 41);
            this.errorIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.errorIcon.TabIndex = 0;
            this.errorIcon.TabStop = false;
            // 
            // deleteMessageLbl
            // 
            this.deleteMessageLbl.AutoSize = true;
            this.deleteMessageLbl.BackColor = System.Drawing.Color.Transparent;
            this.deleteMessageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteMessageLbl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.deleteMessageLbl.Location = new System.Drawing.Point(130, 30);
            this.deleteMessageLbl.Name = "deleteMessageLbl";
            this.deleteMessageLbl.Size = new System.Drawing.Size(258, 20);
            this.deleteMessageLbl.TabIndex = 1;
            this.deleteMessageLbl.Text = "Are you sure you want to delete ?";
            // 
            // confirmDeleteBtn
            // 
            this.confirmDeleteBtn.BackColor = System.Drawing.SystemColors.Control;
            this.confirmDeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmDeleteBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.confirmDeleteBtn.Location = new System.Drawing.Point(179, 76);
            this.confirmDeleteBtn.Name = "confirmDeleteBtn";
            this.confirmDeleteBtn.Size = new System.Drawing.Size(75, 29);
            this.confirmDeleteBtn.TabIndex = 43;
            this.confirmDeleteBtn.Text = "Yes";
            this.confirmDeleteBtn.UseVisualStyleBackColor = false;
            this.confirmDeleteBtn.Click += new System.EventHandler(this.confirmDeleteBtn_Click);
            // 
            // cancelDeleteBtn
            // 
            this.cancelDeleteBtn.BackColor = System.Drawing.SystemColors.Control;
            this.cancelDeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelDeleteBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cancelDeleteBtn.Location = new System.Drawing.Point(273, 76);
            this.cancelDeleteBtn.Name = "cancelDeleteBtn";
            this.cancelDeleteBtn.Size = new System.Drawing.Size(75, 29);
            this.cancelDeleteBtn.TabIndex = 44;
            this.cancelDeleteBtn.Text = "No";
            this.cancelDeleteBtn.UseVisualStyleBackColor = false;
            this.cancelDeleteBtn.Click += new System.EventHandler(this.cancelDeleteBtn_Click);
            // 
            // DeleteMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(506, 117);
            this.Controls.Add(this.cancelDeleteBtn);
            this.Controls.Add(this.confirmDeleteBtn);
            this.Controls.Add(this.deleteMessageLbl);
            this.Controls.Add(this.errorIcon);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Name = "DeleteMessage";
            this.Text = "DeleteMessage";
            ((System.ComponentModel.ISupportInitialize)(this.errorIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox errorIcon;
        private System.Windows.Forms.Label deleteMessageLbl;
        private System.Windows.Forms.Button confirmDeleteBtn;
        private System.Windows.Forms.Button cancelDeleteBtn;
    }
}