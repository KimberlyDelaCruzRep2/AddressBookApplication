﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddressBookApp
{
    public partial class DashboardForm : Form
    {
        private ContactList contactList;
        public DashboardForm()
        {
            contactList = new ContactList();
            InitializeComponent();
        }

        private void addContactBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddContactForm goToAddForm= new AddContactForm();
            goToAddForm.ShowDialog();
            this.Close();
        }

        private void editContactBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            DataGridViewRow selectedRow = contactListTable.SelectedRows[0];
            var contactPerson = new ContactPerson()
            {
                Id = int.Parse(selectedRow.Cells["Id"].Value.ToString()),
                FirstName = selectedRow.Cells["FirstName"].Value.ToString(),
                LastName = selectedRow.Cells["LastName"].Value.ToString(),
                PhoneNumber = selectedRow.Cells["PhoneNumber"].Value.ToString(),
                Address = selectedRow.Cells["Address"].Value.ToString(),
                Gender = selectedRow.Cells["Gender"].Value.ToString(),
            };
            EditContactForm goToEditContactForm = new EditContactForm(contactPerson);
            goToEditContactForm.ShowDialog();
            this.Close();
        }


        private void deleteContactBtn_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = contactListTable.SelectedRows[0];
            var contactPerson = new ContactPerson()
            {
                Id = int.Parse(selectedRow.Cells["Id"].Value.ToString()),
            };
            DeleteMessage showDeleteMessage = new DeleteMessage(contactPerson);
            showDeleteMessage.TopMost = true;
            showDeleteMessage.ShowDialog();
            this.Close();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            var result = contactList.Search(firstNameTxtbox.Text, lastNameTxtbox.Text);
            contactListTable.DataSource = result.DefaultView;
            var hasSelectedRecord = contactListTable.SelectedRows.Count > 0;
            editContactBtn.Enabled = hasSelectedRecord;
            deleteContactBtn.Enabled = hasSelectedRecord;
        }

        private void contactListTable_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var hasSelectedRecord = contactListTable.SelectedRows.Count > 0;
            editContactBtn.Enabled = hasSelectedRecord;
            deleteContactBtn.Enabled = hasSelectedRecord;
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            var hasSelectedRecord = contactListTable.SelectedRows.Count > 0;
            editContactBtn.Enabled = hasSelectedRecord;
            deleteContactBtn.Enabled = hasSelectedRecord;
        }
    }
}
