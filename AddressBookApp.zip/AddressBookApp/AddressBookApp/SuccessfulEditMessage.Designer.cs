﻿namespace AddressBookApp
{
    partial class SuccessfulEditMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SuccessfulEditMessage));
            this.goBackToDashboardBtn = new System.Windows.Forms.Button();
            this.checkIcon = new System.Windows.Forms.PictureBox();
            this.successfulEditMessageLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.checkIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // goBackToDashboardBtn
            // 
            this.goBackToDashboardBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goBackToDashboardBtn.Location = new System.Drawing.Point(216, 76);
            this.goBackToDashboardBtn.Name = "goBackToDashboardBtn";
            this.goBackToDashboardBtn.Size = new System.Drawing.Size(86, 29);
            this.goBackToDashboardBtn.TabIndex = 5;
            this.goBackToDashboardBtn.Text = "Okay";
            this.goBackToDashboardBtn.UseVisualStyleBackColor = true;
            this.goBackToDashboardBtn.Click += new System.EventHandler(this.goBackToDashboardBtn_Click);
            // 
            // checkIcon
            // 
            this.checkIcon.BackColor = System.Drawing.Color.Transparent;
            this.checkIcon.Image = ((System.Drawing.Image)(resources.GetObject("checkIcon.Image")));
            this.checkIcon.Location = new System.Drawing.Point(78, 14);
            this.checkIcon.Name = "checkIcon";
            this.checkIcon.Size = new System.Drawing.Size(46, 41);
            this.checkIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.checkIcon.TabIndex = 4;
            this.checkIcon.TabStop = false;
            // 
            // successfulEditMessageLbl
            // 
            this.successfulEditMessageLbl.AutoSize = true;
            this.successfulEditMessageLbl.BackColor = System.Drawing.Color.Transparent;
            this.successfulEditMessageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.successfulEditMessageLbl.Location = new System.Drawing.Point(130, 35);
            this.successfulEditMessageLbl.Name = "successfulEditMessageLbl";
            this.successfulEditMessageLbl.Size = new System.Drawing.Size(297, 20);
            this.successfulEditMessageLbl.TabIndex = 3;
            this.successfulEditMessageLbl.Text = "Address has been edited successfully!";
            // 
            // SuccessfulEditMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(506, 117);
            this.Controls.Add(this.goBackToDashboardBtn);
            this.Controls.Add(this.checkIcon);
            this.Controls.Add(this.successfulEditMessageLbl);
            this.Name = "SuccessfulEditMessage";
            this.Text = "SuccessfulEditMessage";
            ((System.ComponentModel.ISupportInitialize)(this.checkIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button goBackToDashboardBtn;
        private System.Windows.Forms.PictureBox checkIcon;
        private System.Windows.Forms.Label successfulEditMessageLbl;
    }
}