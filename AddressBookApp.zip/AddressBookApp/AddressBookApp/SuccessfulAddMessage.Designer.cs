﻿namespace AddressBookApp
{
    partial class SuccessfulAddMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SuccessfulAddMessage));
            this.successfulAddMessageLbl = new System.Windows.Forms.Label();
            this.checkIcon = new System.Windows.Forms.PictureBox();
            this.goBackToDashboardBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.checkIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // successfulAddMessageLbl
            // 
            this.successfulAddMessageLbl.AutoSize = true;
            this.successfulAddMessageLbl.BackColor = System.Drawing.Color.Transparent;
            this.successfulAddMessageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.successfulAddMessageLbl.Location = new System.Drawing.Point(123, 38);
            this.successfulAddMessageLbl.Name = "successfulAddMessageLbl";
            this.successfulAddMessageLbl.Size = new System.Drawing.Size(297, 20);
            this.successfulAddMessageLbl.TabIndex = 0;
            this.successfulAddMessageLbl.Text = "Address has been edited successfully!";
            // 
            // checkIcon
            // 
            this.checkIcon.BackColor = System.Drawing.Color.Transparent;
            this.checkIcon.Image = ((System.Drawing.Image)(resources.GetObject("checkIcon.Image")));
            this.checkIcon.Location = new System.Drawing.Point(71, 17);
            this.checkIcon.Name = "checkIcon";
            this.checkIcon.Size = new System.Drawing.Size(46, 41);
            this.checkIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.checkIcon.TabIndex = 1;
            this.checkIcon.TabStop = false;
            // 
            // goBackToDashboardBtn
            // 
            this.goBackToDashboardBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goBackToDashboardBtn.Location = new System.Drawing.Point(218, 76);
            this.goBackToDashboardBtn.Name = "goBackToDashboardBtn";
            this.goBackToDashboardBtn.Size = new System.Drawing.Size(83, 29);
            this.goBackToDashboardBtn.TabIndex = 2;
            this.goBackToDashboardBtn.Text = "Okay";
            this.goBackToDashboardBtn.UseVisualStyleBackColor = true;
            this.goBackToDashboardBtn.Click += new System.EventHandler(this.goBackToDashboardBtn_Click);
            // 
            // SuccessfulAddMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(506, 117);
            this.Controls.Add(this.goBackToDashboardBtn);
            this.Controls.Add(this.checkIcon);
            this.Controls.Add(this.successfulAddMessageLbl);
            this.Name = "SuccessfulAddMessage";
            this.Text = "SuccessfulAddMessage";
            ((System.ComponentModel.ISupportInitialize)(this.checkIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label successfulAddMessageLbl;
        private System.Windows.Forms.PictureBox checkIcon;
        private System.Windows.Forms.Button goBackToDashboardBtn;
    }
}