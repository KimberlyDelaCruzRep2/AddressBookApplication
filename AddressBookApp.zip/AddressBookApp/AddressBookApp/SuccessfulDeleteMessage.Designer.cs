﻿namespace AddressBookApp
{
    partial class SuccessfulDeleteMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SuccessfulDeleteMessage));
            this.goBackToDashboardBtn = new System.Windows.Forms.Button();
            this.successfulDeleteMessageLbl = new System.Windows.Forms.Label();
            this.checkIcon = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.checkIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // goBackToDashboardBtn
            // 
            this.goBackToDashboardBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goBackToDashboardBtn.Location = new System.Drawing.Point(223, 76);
            this.goBackToDashboardBtn.Name = "goBackToDashboardBtn";
            this.goBackToDashboardBtn.Size = new System.Drawing.Size(81, 29);
            this.goBackToDashboardBtn.TabIndex = 4;
            this.goBackToDashboardBtn.Text = "Okay";
            this.goBackToDashboardBtn.UseVisualStyleBackColor = true;
            this.goBackToDashboardBtn.Click += new System.EventHandler(this.goBackToDashboardBtn_Click);
            // 
            // successfulDeleteMessageLbl
            // 
            this.successfulDeleteMessageLbl.AutoSize = true;
            this.successfulDeleteMessageLbl.BackColor = System.Drawing.Color.Transparent;
            this.successfulDeleteMessageLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.successfulDeleteMessageLbl.Location = new System.Drawing.Point(111, 32);
            this.successfulDeleteMessageLbl.Name = "successfulDeleteMessageLbl";
            this.successfulDeleteMessageLbl.Size = new System.Drawing.Size(306, 20);
            this.successfulDeleteMessageLbl.TabIndex = 3;
            this.successfulDeleteMessageLbl.Text = "Address has been deleted successfully!";
            // 
            // checkIcon
            // 
            this.checkIcon.BackColor = System.Drawing.Color.Transparent;
            this.checkIcon.Image = ((System.Drawing.Image)(resources.GetObject("checkIcon.Image")));
            this.checkIcon.Location = new System.Drawing.Point(59, 21);
            this.checkIcon.Name = "checkIcon";
            this.checkIcon.Size = new System.Drawing.Size(46, 41);
            this.checkIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.checkIcon.TabIndex = 5;
            this.checkIcon.TabStop = false;
            // 
            // SuccessfulDeleteMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(506, 117);
            this.Controls.Add(this.checkIcon);
            this.Controls.Add(this.goBackToDashboardBtn);
            this.Controls.Add(this.successfulDeleteMessageLbl);
            this.Name = "SuccessfulDeleteMessage";
            this.Text = "SuccessfulDeleteMessage";
            ((System.ComponentModel.ISupportInitialize)(this.checkIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button goBackToDashboardBtn;
        private System.Windows.Forms.Label successfulDeleteMessageLbl;
        private System.Windows.Forms.PictureBox checkIcon;
    }
}