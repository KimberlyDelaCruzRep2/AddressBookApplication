﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddressBookApp
{
    public partial class AddContactForm : Form
    {
        private ContactList contactList;
        private string selectedGender = "F";
        public AddContactForm()
        {
            contactList = new ContactList();
            InitializeComponent();
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            ContactPerson newContactPerson = new ContactPerson()
            {
                FirstName = firstNameTxtbox.Text,
                LastName = lastNameTxtbox.Text,
                PhoneNumber = phoneNumTxtbox.Text,
                Address = addressTxtbox.Text,
                Gender = selectedGender
            };

            var result = contactList.Add(newContactPerson);

            if (result > 0)
            {
                SuccessfulAddMessage showSuccessfuleAddMessage = new SuccessfulAddMessage();
                showSuccessfuleAddMessage.TopMost = true;
                showSuccessfuleAddMessage.ShowDialog();
                this.Close();
            }
            else
            {
                InsertEntryErrorMsg.Text = newContactPerson.GetErrorMessage("transactionErrorMessage");
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardForm goToDashboardForm = new DashboardForm();
            goToDashboardForm.ShowDialog();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void femaleGenRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            selectedGender = "F";
        }

        private void maleGenRadioBtn_CheckedChanged(object sender, EventArgs e)
        {
            selectedGender = "M";
        }
    }
}
