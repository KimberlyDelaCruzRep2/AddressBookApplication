﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace AddressBookApp
{
    public partial class ContactList
    {
        //Declaring all fields to be used in the application for SQLite
        private SQLiteConnection sqlCon;

        public ContactList()
        {
            sqlCon = new SQLiteConnection(@"Data Source=C:\Users\home\Documents\Kim - Automation Projects\MyDatabase.db;Version=3;");
        }

        private SQLiteCommand createCommand()
        {
            SQLiteCommand command = new SQLiteCommand();
            command.Connection = sqlCon;
            return command;
        }

        public int Add(ContactPerson newContact)
        {
            try
            {
                SQLiteCommand command = createCommand();
                sqlCon.Open();

                command.CommandText =
                    "INSERT INTO Contact (FirstName, LastName, PhoneNumber, Address, Gender) VALUES (@FirstName, @LastName, @PhoneNumber, @Address, @Gender)";
                List<SQLiteParameter> parameters = new List<SQLiteParameter>();
                parameters.Add(new SQLiteParameter("@firstName", newContact.FirstName));
                parameters.Add(new SQLiteParameter("@lastName", newContact.LastName));
                parameters.Add(new SQLiteParameter("@phoneNumber", newContact.PhoneNumber));
                parameters.Add(new SQLiteParameter("@address", newContact.Address));
                parameters.Add(new SQLiteParameter("@Gender", newContact.Gender));
                command.Parameters.AddRange(parameters.ToArray());
                var result = command.ExecuteNonQuery();
                sqlCon.Close();
                return result;
            }
            catch (SQLiteException ex)
            {
                if (ex.ResultCode == SQLiteErrorCode.Constraint)
                {
                    newContact.SetErrorMessage("transactionErrorMessage", "Record already exists");
                }
            }
            return -1;
        }

        public DataTable Search(string firstName, string lastName)
        {
            SQLiteCommand command = createCommand();
            command.CommandText = "SELECT * FROM Contact WHERE firstName like @firstName AND lastName like @lastName";
            List<SQLiteParameter> parameters = new List<SQLiteParameter>();
            parameters.Add(new SQLiteParameter("@firstName", $"%{firstName}%"));
            parameters.Add(new SQLiteParameter("@lastName", $"%{lastName}%"));
            command.Parameters.AddRange(parameters.ToArray());
            SQLiteDataAdapter dataAdapter = new SQLiteDataAdapter();
            dataAdapter.SelectCommand = command;
            DataTable result = new DataTable();
            dataAdapter.Fill(result);
            return result;
        }

        public int Edit(ContactPerson contactPerson)
        {
            SQLiteCommand command = createCommand();
            sqlCon.Open();
            command.CommandText =
                "UPDATE Contact SET firstName = @FirstName, lastName = @LastName, phoneNumber = @PhoneNumber, address = @Address, gender = @Gender WHERE Id = @ID";
            List<SQLiteParameter> parameters = new List<SQLiteParameter>();
            parameters.Add(new SQLiteParameter("@Id", contactPerson.Id));
            parameters.Add(new SQLiteParameter("@FirstName", contactPerson.FirstName));
            parameters.Add(new SQLiteParameter("@LastName", contactPerson.LastName));
            parameters.Add(new SQLiteParameter("@PhoneNumber", contactPerson.PhoneNumber));
            parameters.Add(new SQLiteParameter("@Address", contactPerson.Address));
            parameters.Add(new SQLiteParameter("@Gender", contactPerson.Gender));
            command.Parameters.AddRange(parameters.ToArray());
            var result = command.ExecuteNonQuery();
            sqlCon.Close();
            return result;
        }

        public int Delete(ContactPerson contactPerson)
        {
            SQLiteCommand command = createCommand();
            sqlCon.Open();
            command.CommandText = "DELETE FROM Contact WHERE Id = @ID";
            List<SQLiteParameter> parameters = new List<SQLiteParameter>();
            parameters.Add(new SQLiteParameter("@ID", contactPerson.Id));
            command.Parameters.AddRange(parameters.ToArray());
            var result = command.ExecuteNonQuery();
            sqlCon.Close();
            return result;
        }
    }
}
