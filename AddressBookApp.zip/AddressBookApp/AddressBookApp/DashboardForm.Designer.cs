﻿namespace AddressBookApp
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardForm));
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.firtNameLbl = new System.Windows.Forms.Label();
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.lastNameTxtbox = new System.Windows.Forms.TextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.addContactBtn = new System.Windows.Forms.Button();
            this.firstNameTxtbox = new System.Windows.Forms.TextBox();
            this.editContactBtn = new System.Windows.Forms.Button();
            this.deleteContactBtn = new System.Windows.Forms.Button();
            this.contactListTable = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.contactListTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 529);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // firtNameLbl
            // 
            this.firtNameLbl.AutoSize = true;
            this.firtNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.firtNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firtNameLbl.Location = new System.Drawing.Point(122, 27);
            this.firtNameLbl.Name = "firtNameLbl";
            this.firtNameLbl.Size = new System.Drawing.Size(92, 20);
            this.firtNameLbl.TabIndex = 2;
            this.firtNameLbl.Text = "First Name";
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.AutoSize = true;
            this.lastNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.lastNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameLbl.Location = new System.Drawing.Point(375, 27);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(91, 20);
            this.lastNameLbl.TabIndex = 3;
            this.lastNameLbl.Text = "Last Name";
            // 
            // lastNameTxtbox
            // 
            this.lastNameTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastNameTxtbox.Location = new System.Drawing.Point(379, 50);
            this.lastNameTxtbox.Name = "lastNameTxtbox";
            this.lastNameTxtbox.Size = new System.Drawing.Size(224, 27);
            this.lastNameTxtbox.TabIndex = 5;
            // 
            // searchBtn
            // 
            this.searchBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBtn.Location = new System.Drawing.Point(622, 50);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(91, 29);
            this.searchBtn.TabIndex = 6;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // addContactBtn
            // 
            this.addContactBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addContactBtn.Location = new System.Drawing.Point(25, 115);
            this.addContactBtn.Name = "addContactBtn";
            this.addContactBtn.Size = new System.Drawing.Size(78, 29);
            this.addContactBtn.TabIndex = 8;
            this.addContactBtn.Text = "Add";
            this.addContactBtn.UseVisualStyleBackColor = true;
            this.addContactBtn.Click += new System.EventHandler(this.addContactBtn_Click);
            // 
            // firstNameTxtbox
            // 
            this.firstNameTxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstNameTxtbox.Location = new System.Drawing.Point(124, 50);
            this.firstNameTxtbox.Name = "firstNameTxtbox";
            this.firstNameTxtbox.Size = new System.Drawing.Size(224, 27);
            this.firstNameTxtbox.TabIndex = 9;
            // 
            // editContactBtn
            // 
            this.editContactBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editContactBtn.Location = new System.Drawing.Point(124, 115);
            this.editContactBtn.Name = "editContactBtn";
            this.editContactBtn.Size = new System.Drawing.Size(78, 29);
            this.editContactBtn.TabIndex = 10;
            this.editContactBtn.Text = "Edit";
            this.editContactBtn.UseVisualStyleBackColor = true;
            this.editContactBtn.Click += new System.EventHandler(this.editContactBtn_Click);
            // 
            // deleteContactBtn
            // 
            this.deleteContactBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteContactBtn.Location = new System.Drawing.Point(226, 115);
            this.deleteContactBtn.Name = "deleteContactBtn";
            this.deleteContactBtn.Size = new System.Drawing.Size(78, 29);
            this.deleteContactBtn.TabIndex = 11;
            this.deleteContactBtn.Text = "Delete";
            this.deleteContactBtn.UseVisualStyleBackColor = true;
            this.deleteContactBtn.Click += new System.EventHandler(this.deleteContactBtn_Click);
            // 
            // contactListTable
            // 
            this.contactListTable.AllowUserToAddRows = false;
            this.contactListTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.contactListTable.Location = new System.Drawing.Point(25, 153);
            this.contactListTable.MultiSelect = false;
            this.contactListTable.Name = "contactListTable";
            this.contactListTable.RowTemplate.Height = 24;
            this.contactListTable.Size = new System.Drawing.Size(688, 364);
            this.contactListTable.TabIndex = 12;
            this.contactListTable.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.contactListTable_RowHeaderMouseClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(85, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(735, 529);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.contactListTable);
            this.Controls.Add(this.deleteContactBtn);
            this.Controls.Add(this.editContactBtn);
            this.Controls.Add(this.firstNameTxtbox);
            this.Controls.Add(this.addContactBtn);
            this.Controls.Add(this.searchBtn);
            this.Controls.Add(this.lastNameTxtbox);
            this.Controls.Add(this.lastNameLbl);
            this.Controls.Add(this.firtNameLbl);
            this.Controls.Add(this.splitter1);
            this.Name = "DashboardForm";
            this.Text = "Address Book Application";
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.contactListTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label firtNameLbl;
        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.TextBox firstNameTxtbox;
        private System.Windows.Forms.TextBox lastNameTxtbox;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.Button addContactBtn;
        private System.Windows.Forms.Button editContactBtn;
        private System.Windows.Forms.Button deleteContactBtn;
        private System.Windows.Forms.DataGridView contactListTable;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

