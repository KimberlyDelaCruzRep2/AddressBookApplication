﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AddressBookApp
{
    public partial class ContactPerson
    {
        private Dictionary<string, string> errorMessages = new Dictionary<string, string>();
        public bool IsValid
        {
            get
            {
                Validate();
                return errorMessages.Count == 0;
            }
        }
        private string firstNameProperty = "FirstName";
        private string lastNameProperty = "LastName";
        private string phoneNumberProperty = "PhoneNumber";
        private string addressProperty = "Address";
        public string GetErrorMessage(string errorKey)
        {
            if (errorMessages.ContainsKey(errorKey))
            {
                var result = errorMessages[errorKey];
                return result;
            }
            return string.Empty;
        }

        public void SetErrorMessage(string errorKey, string errorMessage)
        {
            errorMessages[errorKey] = errorMessage;
        }

        public void Validate()
        {
            errorMessages.Clear();
            #region firstName validation
            if (string.IsNullOrWhiteSpace(FirstName))
            {
                errorMessages[firstNameProperty] = "Firstname is required.";
            }
            else
            {
                if (FirstName.Length > 30)
                {
                    errorMessages[firstNameProperty] = "Firstname should not greater than 30 characters.";
                }
                else if (!Regex.IsMatch(FirstName, @"^[a-zA-Z]+[a-zA-Z]$"))
                {
                    errorMessages[firstNameProperty] = "Firstname should only contain alphabet characters.";
                }

            }
            #endregion
            #region Lastname validation
            if (string.IsNullOrWhiteSpace(LastName))
            {
                errorMessages[lastNameProperty] = "Lastname is required.";
            }
            else
            {
                if (LastName.Length > 30)
                {
                    errorMessages[lastNameProperty] = "Lastname should not greater than 30 characters.";
                }
                else if (!Regex.IsMatch(LastName, @"^[a-zA-Z]+[a-zA-Z]$"))
                {
                    errorMessages[lastNameProperty] = "Lastname should only contain alphabet characters.";
                }
            }
            #endregion

            #region Phone number validation
            if (PhoneNumber != null)
            {
                if (PhoneNumber.Length > 15)
                {
                    errorMessages[phoneNumberProperty] = "Phone number should not greater than 15 characters.";
                }
                else if (!Regex.IsMatch(PhoneNumber, "^[0-9]*[0-9]$"))
                {
                    errorMessages[phoneNumberProperty] = "Phone number should only contain numbers.";
                }
            }
            #endregion

            #region Address validation
            if (Address != null)
            {
                if (Address.Length > 255)
                {
                    errorMessages[addressProperty] = "Address should not greater than 255 characters.";
                }
            }
            #endregion 

        }

    }
}
